# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AndrewYurlow/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AndrewYurlow/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/17b566db5cc3ff3862ae/maintainability)](https://codeclimate.com/github/AndrewYurlow/python-project-49/maintainability)',
    'author': 'andrew yurlow',
    'author_email': 'andrewyurlow@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
