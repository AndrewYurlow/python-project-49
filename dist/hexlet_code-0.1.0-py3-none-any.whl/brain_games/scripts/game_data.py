data = {
    "question_amount": 3,
    "user_is_won": False,
    "user_name": '',
    "operators": ["+", "-", "*"]
}
