data = {
    "question_amount": 3,
    "user_is_won": False,
    "user_name": '',
    "rand_end": 25,
    "rand_start": 1,
    "operators": ["+", "-", "*"],
    "progression_len": 10,
    "progression_step_start": 2,
    "progression_step_end": 5
}
